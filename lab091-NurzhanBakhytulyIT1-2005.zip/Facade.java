public class Facade {


  public static void Operation1() {

    System.out.println("Operation 1\n" + SubsystemA.A1() + SubsystemA.A2() + SubsystemB.B1());

  }

  public static void Operation2() {

    System.out.println("Operation 2\n" + SubsystemB.B1() +SubsystemC.C1());

  }

}