public class SubsystemB extends Facade{

    public static String B1() {

        return "Subsystem B, Method B1\n";

    }
}

