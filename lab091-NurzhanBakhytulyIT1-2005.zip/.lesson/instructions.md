https://eduiitu.sharepoint.com/:w:/s/DesignPatterns/EfpKLEFQzt1In7xFsTMF5zABGu0faOS73mh0N0t8T1egSw?e=mOTtJe

ToDo: Read Facade Pattern

Write program in Java of last example

Hints:
1. https://refactoring.guru/design-patterns/facade
2. https://www.javatpoint.com/facade-design-pattern

