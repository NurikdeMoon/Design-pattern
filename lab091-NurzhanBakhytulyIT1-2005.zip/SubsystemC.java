public class SubsystemC extends Facade{

    public static String C1() {
        return "Subsystem C, Method C1\n";
    }

}