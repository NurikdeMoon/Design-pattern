public class Main {

    public static void main(String[] args) {
        
      Facade.Operation1();
          try{
            Thread.sleep(1000);
        }
        catch(InterruptedException e){
            System.out.println("Thread has been interrupted");
        }
      Facade.Operation2();
        

    }

}