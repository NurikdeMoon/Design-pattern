public class SubsystemA extends Facade{

    public static String A1() {

        return "Subsystem A, Method A1\n";

    }

    public static String A2() {

        return "Subsystem A, Method A2\n";

    }

}