public class Infantryman extends Warrior{
    @Override
    public String Info()
    {
        return "Infantryman";
    }
}