public class Horseman extends Warrior
{
    @Override
    public String Info()
    {
        return "Horseman";
    }
}