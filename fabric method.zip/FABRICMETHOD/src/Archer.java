public class Archer extends Warrior{
    @Override
    public String Info() {
        return "Archer";
    }
}
