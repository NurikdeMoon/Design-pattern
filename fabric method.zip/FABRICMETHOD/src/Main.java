class Main {
    public static void main(String[] args) { 
         Warrior[] warriors = new Warrior[3];
         warriors[0] = (new ArcherFactory()).WarriorCreate();
         warriors[1] = (new HorsemanFactory()).WarriorCreate();
         warriors[2] = (new InfantrymanFactory()).WarriorCreate();

          for (int i = 0; i < 3; i++) {
            System.out.println(warriors[i].Info());

    }
}
}
  