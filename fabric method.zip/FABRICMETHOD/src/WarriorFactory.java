public abstract class WarriorFactory{
    public abstract Warrior WarriorCreate();
}