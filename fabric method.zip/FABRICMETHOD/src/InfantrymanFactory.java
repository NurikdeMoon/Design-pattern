public class InfantrymanFactory extends WarriorFactory {
    @Override
    public Warrior WarriorCreate()
    {
        return new Infantryman();
    }
}