public class ArcherFactory extends WarriorFactory {
    @Override
    public Warrior WarriorCreate()
    {
        return new Archer();
    }
}