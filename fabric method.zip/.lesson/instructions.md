https://eduiitu.sharepoint.com/:w:/s/DesignPatterns/EdSLz8YGkdxGrHXPsDdQZ7IBe3_S7XFBWIupatcPlYFzEQ?e=bpjrpT

ToDo: Read until 8 page, Abstract Fabric

Write program in Java on picture 5

Hints:
1. https://refactoring.guru/design-patterns/factory-method/java/example
2. https://www.javatpoint.com/factory-method-design-pattern

In Result, after run program, you must see:

![image](image.png)

After that check you code with prepared unit tests

![image](image_2.png)

If all unit tests will completed, press Submit button

![image](image_3.png)

