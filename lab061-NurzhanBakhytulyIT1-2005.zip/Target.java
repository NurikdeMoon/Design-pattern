public class Target {
    public void Request() {

        System.out.println("	");
    }
}