public class Adapter extends Target {
    public Adaptee adaptee = new Adaptee();

    @Override
    public void Request() {


        adaptee.SpecificRequest();
    }
}