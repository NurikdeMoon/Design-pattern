public class Adaptee {
    public void SpecificRequest() {
        System.out.println("Called SpecificRequest()");
    }
}