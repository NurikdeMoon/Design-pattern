import Characters.*;

public class Main {
    public static void main(String[] args) {
        String document = "AAZZBBZB";
        char[] chars = document.toCharArray();
        CharacterFactory f = new CharacterFactory();
        int pointSize = 10;
        for (char c : chars) {
            pointSize++;
            Character character = f.GetCharacter(c);
            character.Display(pointSize);
        }
    }
}