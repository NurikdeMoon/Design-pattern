import java.util.*;

public class CharacterFactory {

    private Hashtable<java.lang.Character, Character> characters = new Hashtable<>();

    public Character GetCharacter(char key) {
        Character character = (Character) characters.get(key);
        if (character != null) 
          return character;
        switch (key) {
            case 'A':
                character = new CharacterA();
                break;
            case 'B':
                character = new CharacterB();
                break;
            case 'Z':
                character = new CharacterZ();
                break;
        }
        characters.put(key, character);
        return character;
    }
}