public class Leaf extends Component {
    public Leaf(String name) {
        super(name);
    }

    @Override
    public void Display(String depth) {
        System.out.println(new String("-" + depth) + name);
    }
}
