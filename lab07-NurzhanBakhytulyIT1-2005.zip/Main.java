import java.util.ArrayList;
import java.util.List;

public class Main {
  public static void main(String[] args) {

    Composite root = new Composite("root");

    root.Add(new Leaf("Leaf A"));
    root.Add(new Leaf("Leaf B"));

    Composite comp = new Composite("Composite X");
    comp.Add(new Leaf("Leaf XA"));
    comp.Add(new Leaf("Leaf XB"));
    root.Add(comp);
    root.Add(new Leaf("Leaf C"));

    Leaf leaf = new Leaf("Leaf D");
    root.Add(leaf);
    root.Remove(leaf);

    root.Display(1);

  }

  public abstract static class Component {
    protected String name;

    public Component(String name) {
      this.name = name;
    }

    public abstract void Display(int depth);
  }

  public static class Composite extends Component {
    private List<Component> children = new ArrayList();

    public Composite(String name) {
      super(name);
    }

    public void Add(Component component) {
      children.add(component);
    }

    public void Remove(Component component) {
      children.remove(component);
    }

    @Override
    public void Display(int depth) {
      System.out.println(new String("-" + depth) + name);
      for (Component component : children) {
        component.Display(depth + 2);
      }
    }
  }

  static class Leaf extends Component {
    public Leaf(String name) {
      super(name);
    }

    @Override
    public void Display(int depth) {
      System.out.println(new String("-" + depth) + name);
    }
  }
  /*
   * Map<String, String> map = new HashMap<String, String>();
   * map.put("0", " ");
   * map.put("1", "-");
   * map.put("2", "--");
   * map.put("3", "---");
   * map.put("4", "----");
   * map.put("5", "-----");
   * map.put("6", "------");
   * map.put("7", "-------");
   * map.put("8", "--------");
   * map.put("9", "---------");
   */
}