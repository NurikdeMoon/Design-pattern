public class Horseman extends Warrior
{
	@Override
	public final Warrior dublicate()
	{
	  return new Horseman();
	}
	@Override
	public final void info()
	{
	  System.out.print("Horseman\n");
	}
}