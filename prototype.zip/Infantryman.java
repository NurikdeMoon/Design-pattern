public class Infantryman extends Warrior
{
	@Override
	public final Warrior dublicate()
	{
	  return new Infantryman();
	}
	@Override
	public final void info()
	{
	  System.out.print("Infantryman\n");
	}
}