public class Archer extends Warrior
{
	@Override
	public final Warrior dublicate()
	{
	  return new Archer();
	}
	@Override
	public final void info()
	{
	  System.out.print("Archer\n");
	}
}