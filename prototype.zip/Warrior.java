public abstract class Warrior
{
	public abstract Warrior dublicate();
	public abstract void info();
}