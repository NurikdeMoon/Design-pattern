import java.util.*;

public class Main
{
	public static void main(String[] args)
	{
	  PrototypeFactory factory = new PrototypeFactory();
	  ArrayList<Warrior> war = new ArrayList<>();
	  war.add(factory.createInfantryman());
	  war.add(factory.createArcher());
	  war.add(factory.createHorseman());

		for (Warrior warrior : war) {
			warrior.info();
		}
	}
}