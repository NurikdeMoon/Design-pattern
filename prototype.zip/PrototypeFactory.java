public class PrototypeFactory
{
	public Infantryman createInfantryman_prototype = new Infantryman();
	public final Warrior createInfantryman()
	{
	  return createInfantryman_prototype.dublicate();
	}
	public Archer createArcher_prototype = new Archer();
	public final Warrior createArcher()
	{
	  return createArcher_prototype.dublicate();
	}
	public Horseman createHorseman_prototype = new Horseman();
	public final Warrior createHorseman()
	{
	  return createHorseman_prototype.dublicate();
	}
}