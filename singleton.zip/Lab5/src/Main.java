
public class Main

{

    public static void main(String[] args) {

        var s1 = Singleton.GetInstance();

        var s2 = Singleton.GetInstance();



        System.out.println(s1.getName());

        System.out.println(s2.getName());



        s1.setName("Serik");

        s2.setName("Diana");



        System.out.println(s1.getName());

        System.out.println(s2.getName());

    }

}