https://eduiitu.sharepoint.com/:w:/s/DesignPatterns/EdSLz8YGkdxGrHXPsDdQZ7IBe3_S7XFBWIupatcPlYFzEQ?e=5J3vBB

ToDo: Read Singleton Pattern (Шаблон Одиночка)

Write program in Java of last example

Hints:
1. https://refactoring.guru/design-patterns/singleton
2. https://www.javatpoint.com/singleton-design-pattern-in-java