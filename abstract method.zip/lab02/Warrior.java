public abstract class Warrior{ 
  public abstract String Info(); 

  } 
