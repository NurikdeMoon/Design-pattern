public class RomanInfantryman extends Infantryman { 
@Override
public  String Info(){ 
  return "RomanInfantryman"; 
  }
} 