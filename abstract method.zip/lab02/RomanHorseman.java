public class RomanHorseman extends Horseman { 
@Override
public  String Info() { 
  return "RomanHorseman"; 
  }
}  