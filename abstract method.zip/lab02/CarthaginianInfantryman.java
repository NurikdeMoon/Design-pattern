 public class CarthaginianInfantryman extends Infantryman 

  { 

 
@Override
    public String Info() 

    { 

      return "CarthaginianInfantryman"; 

    } 

  } 