public class CarthaginianHorseman extends Horseman { 
@Override
public  String Info() { 
return "CarthaginianHorseman"; 
  } 
} 