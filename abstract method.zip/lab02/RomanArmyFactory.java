public class RomanArmyFactory extends ArmyFactory 

  { 
    @Override
    public  Infantryman CreateInfantryman() 

    { 

      return new RomanInfantryman(); 

    } 
    @Override
    public  Archer CreateArcher() 

    { 

      return new RomanArcher(); 

    } 
    @Override
    public  Horseman CreateHorseman() 

    { 

      return new RomanHorseman(); 

    } 

  } 