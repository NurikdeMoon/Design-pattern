public class CarthaginianArcher extends Archer { 
@Override
public  String Info() { 
return "CarthaginianArcher"; 
  } 
} 
