public class CarthaginianArmyFactory extends ArmyFactory 

  { 
    @Override
    public  Infantryman CreateInfantryman() 

    { 

      return new CarthaginianInfantryman(); 

    } 
    @Override
    public  Archer CreateArcher() 

    { 

      return new CarthaginianArcher(); 

    } 
    @Override
    public  Horseman CreateHorseman() 

    { 

      return new CarthaginianHorseman(); 

    } 

  } 