  public class Army 

  { 

    private ArmyFactory _armyFactory; 

    private Warrior[] _army; 

    public Army(ArmyFactory parFactory) 

    { 

      _armyFactory = parFactory; 

    } 

    public Warrior[] CreateArmy() 

    { 

      _army = new Warrior[3]; 

      _army[0] = _armyFactory.CreateInfantryman(); 

      _army[1] = _armyFactory.CreateArcher(); 

      _army[2] = _armyFactory.CreateHorseman(); 

      return _army; 

    } 

  } 