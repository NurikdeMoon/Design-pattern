public class RomanArcher extends Archer { 
@Override
public  String Info() {
  return "RomanArcher"; 
  } 

} 