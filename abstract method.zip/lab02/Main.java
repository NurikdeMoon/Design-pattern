public class Main{
  public static void main(String[] args){

RomanArmyFactory romanArmyFactory = new RomanArmyFactory(); 

      CarthaginianArmyFactory carthaginianArmyFactory = new CarthaginianArmyFactory(); 

 

      Army romanArmy = new Army(romanArmyFactory); 

      Warrior[] romanWarriors = romanArmy.CreateArmy(); 

 

      Army carthaginianArmy = new Army(carthaginianArmyFactory); 

      Warrior[] carthaginianWarriors = carthaginianArmy.CreateArmy(); 
     for (int i = 0; i<3; i++){
      System.out.println(romanWarriors[i].Info());
      
    }
    for (int i = 0; i<3; i++){
      System.out.println(carthaginianWarriors[i].Info());
      
    }


    
}}