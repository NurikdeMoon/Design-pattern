public abstract class ArmyFactory { 

    public abstract Infantryman CreateInfantryman(); 

    public abstract Archer CreateArcher(); 

    public abstract Horseman CreateHorseman(); 

  } 