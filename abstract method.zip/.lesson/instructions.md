https://eduiitu.sharepoint.com/:w:/s/DesignPatterns/EdSLz8YGkdxGrHXPsDdQZ7IBe3_S7XFBWIupatcPlYFzEQ?e=5J3vBB

ToDo: Read Abstract Fabric

Write program in Java

Result fot Unit tests must be:
![image](image_2.png)

Hints:
1. https://refactoring.guru/design-patterns/abstract-factory
2. https://www.javatpoint.com/abstract-factory-pattern

