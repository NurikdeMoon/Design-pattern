https://eduiitu.sharepoint.com/:w:/s/DesignPatterns/EfpKLEFQzt1In7xFsTMF5zABGu0faOS73mh0N0t8T1egSw?e=mOTtJe

ToDo: Read Proxy Pattern

Write program in Java of last example

Hints:
1. https://refactoring.guru/design-patterns/proxy
2. https://www.javatpoint.com/proxy-design-pattern

