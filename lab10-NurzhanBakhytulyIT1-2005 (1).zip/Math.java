public class Math implements IMath {

    public Math() {
       try{
            
            Thread.sleep(1000);
            System.out.println("Create object Math. Wait...");
         
            Thread.sleep(1000);
            
        }
        catch(InterruptedException e){
          System.out.println("Thread has been interrupted");
        }
      

    }


    public double Add(double x, double y) {
        return x + y;
    }

    public double Sub(double x, double y) {
        return x - y;
    }

    public double Mul(double x, double y) {
        return x * y;
    }

    public double Div(double x, double y) {
        return x / y;
    }

}