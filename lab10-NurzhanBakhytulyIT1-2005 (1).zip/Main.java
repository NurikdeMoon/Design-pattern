public class Main {

    public static void main(String[] args) {

        IMath p = new MathProxy();
      
        System.out.println("4 + 2 = " + p.Add(4, 2));
    
        System.out.println("4 - 2 = " + p.Sub(4, 2));

        System.out.println("4 * 2 = " + p.Mul(4, 2));

        System.out.println("4 / 2 = " + p.Div(4, 2));

    }

}