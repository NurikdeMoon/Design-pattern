public class MathProxy implements IMath {

    private Math math = new Math();


    public MathProxy() {

        math = null;

    }


    public double Add(double x, double y) {

        return x + y;

    }


    public double Sub(double x, double y) {

        return x - y;

    }


    public double Mul(double x, double y) {

        if (math == null) {
            math = new Math();
        }

        return math.Mul(x, y);

    }


    public double Div(double x, double y) {

        if (math == null) {
            math = new Math();
        }

        return math.Div(x, y);

    }

}