public class CoreFunctionality extends Component {

    @Override
    public void DoThis() {
        System.out.println("CoreFunctionality");
    }
}