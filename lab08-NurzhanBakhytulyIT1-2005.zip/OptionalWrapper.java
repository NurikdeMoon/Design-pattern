public abstract class OptionalWrapper extends Component {
    protected Component component;

    public void SetComponent(Component component) {
        this.component = component;
    }

    @Override
    public void DoThis() {
        if (component != null) {
            component.DoThis();
        }
    }
}