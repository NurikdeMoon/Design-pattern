public class OptionalTwo extends OptionalWrapper {
    @Override
    public void DoThis() {
        System.out.println("---------------------");
        super.DoThis();
        System.out.println("---------------------");
    }
}