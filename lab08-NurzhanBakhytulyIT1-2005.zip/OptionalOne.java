public class OptionalOne extends OptionalWrapper {
    @Override
    public void DoThis() {
        super.DoThis();
    }
}