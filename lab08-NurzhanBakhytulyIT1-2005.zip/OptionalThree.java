public class OptionalThree extends OptionalWrapper {
    @Override
    public void DoThis ()
    {
        System.out.print("\u001B[0;33m");
        super.DoThis();
        System.out.print("\u001B[0m");
    }

}