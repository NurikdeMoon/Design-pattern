public class Main {
    public static void main(String[] args) {
        CoreFunctionality oC = new CoreFunctionality();
        OptionalOne oA = new OptionalOne();
        OptionalTwo oB = new OptionalTwo();
        OptionalThree oT = new OptionalThree();

        oA.SetComponent(oC);
        oT.SetComponent(oA);
        oB.SetComponent(oT);
        System.out.println("\nПервая обёртка");

        oA.DoThis();

        System.out.println("\nВторая обёртка");

        oB.DoThis();

        System.out.println("\nТретья обёртка");
        oT.DoThis();
    }


}