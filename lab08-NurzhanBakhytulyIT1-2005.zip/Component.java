public abstract class Component {
    public abstract void DoThis();
}