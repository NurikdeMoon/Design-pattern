class Infantryman {
    public void info() {
        System.out.print("Infantryman\n");
    }
}