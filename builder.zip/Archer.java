class Archer {
    public void info() {
        System.out.print("Archer\n");
    }
}
