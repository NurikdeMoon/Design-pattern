class CarthaginianArcher extends Archer {
    @Override
    public void info() {
        System.out.print("CarthaginianArcher\n");
    }
}