class RomanArmyBuilder extends ArmyBuilder {
    public final void createArmy() {
        army = new Army();
    }

    public final void buildInfantryman() {
        army.infantryman.add(new RomanInfantryman());
    }

    public final void buildArcher() {
        army.archers.add(new RomanArcher());
    }

    public final void buildHorseman() {
        army.horsemans.add(new RomanHorseman());
    }

    public final void buildCatapult() {
        army.catapults.add(new RomanCatapult());
    }
}


