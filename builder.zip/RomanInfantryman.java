class RomanInfantryman extends Infantryman {
    @Override
    public void info() {
        System.out.print("RomanInfantryman\n");
    }
}