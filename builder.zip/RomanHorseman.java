class RomanHorseman extends Horseman {
    @Override
    public void info() {
        System.out.print("RomanHorseman\n");
    }
}