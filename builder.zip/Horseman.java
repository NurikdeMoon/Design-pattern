class Horseman {
    public void info() {
        System.out.print("Horseman\n");
    }
}
