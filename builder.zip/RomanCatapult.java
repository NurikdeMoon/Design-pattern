class RomanCatapult extends Catapult {
    @Override
    public void info() {
        System.out.print("RomanCatapult\n");
    }
}
