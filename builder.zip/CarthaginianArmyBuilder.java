class CarthaginianArmyBuilder extends ArmyBuilder {
    public final void createArmy() {
        army = new Army();
    }

    public final void buildInfantryman() {
        army.infantryman.add(new CarthaginianInfantryman());
    }

    public final void buildArcher() {
        army.archers.add(new CarthaginianArcher());
    }

    public final void buildHorseman() {
        army.horsemans.add(new CarthaginianHorseman());
    }

    public final void buildCatapult() {
        army.catapults.add(new CarthaginianCatapult());
    }
}

