class Director {
    public final Army createArmy(ArmyBuilder builder) {
        builder.createArmy();
        builder.buildInfantryman();
        builder.buildArcher();
        builder.buildHorseman();
        builder.buildCatapult();
        return (builder.getArmy());
    }
}