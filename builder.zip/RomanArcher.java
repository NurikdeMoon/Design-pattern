class RomanArcher extends Archer {
    @Override
    public void info() {
        System.out.print("RomanArcher\n");
    }
}