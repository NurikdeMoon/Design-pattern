class CarthaginianInfantryman extends Infantryman {
    @Override
    public void info() {
        System.out.print("CarthaginianInfantryman\n");
    }
}
