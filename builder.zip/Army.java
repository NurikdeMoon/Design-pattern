import java.util.ArrayList;

class Army {
    public ArrayList<Infantryman> infantryman = new ArrayList<Infantryman>();
    public ArrayList<Archer> archers = new ArrayList<Archer>();
    public ArrayList<Horseman> horsemans = new ArrayList<Horseman>();
    public ArrayList<Catapult> catapults = new ArrayList<Catapult>();

    public final void info() {
        int i;
        for (i = 0; i < infantryman.size(); ++i) {
            infantryman.get(i).info();
        }
        for (i = 0; i < archers.size(); ++i) {
            archers.get(i).info();
        }
        for (i = 0; i < horsemans.size(); ++i) {
            horsemans.get(i).info();
        }
        for (i = 0; i < catapults.size(); ++i) {
            catapults.get(i).info();
        }
    }
}