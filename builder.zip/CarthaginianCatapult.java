class CarthaginianCatapult extends Catapult {
    @Override
    public void info() {
        System.out.print("CarthaginianCatapult\n");
    }
}