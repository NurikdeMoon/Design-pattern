class ArmyBuilder {
    protected Army army;

    public ArmyBuilder() {
        this.army = null;
    }

    public void close() {
    }

    public void createArmy() {
    }

    public void buildInfantryman() {
    }

    public void buildArcher() {
    }

    public void buildHorseman() {
    }

    public void buildCatapult() {
    }

    public Army getArmy() {
        return army;
    }
}
