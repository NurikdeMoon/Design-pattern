class Main {
    public static void main(String[] args) {
        Director director = new Director();
        RomanArmyBuilder Roman_builder = new RomanArmyBuilder();
        CarthaginianArmyBuilder Carthaginian_builder = new CarthaginianArmyBuilder();

        Army RomanArmy = director.createArmy(Roman_builder);
Army CarthaginianArmy=director.createArmy(Carthaginian_builder);
        RomanArmy.info();
        CarthaginianArmy.info();
    }
}