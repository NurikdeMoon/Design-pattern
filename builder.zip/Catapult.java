class Catapult {
    public void info() {
        System.out.print("Catapult\n");
    }
}
