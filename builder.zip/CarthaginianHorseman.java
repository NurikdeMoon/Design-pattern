class CarthaginianHorseman extends Horseman {
    @Override
    public void info() {
        System.out.print("CarthaginianHorseman\n");
    }
}